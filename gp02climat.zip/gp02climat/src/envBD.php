<?php
$_ENV['host'] = "ust-infoserv.univlehavre.lan"; //host = localhost
$_ENV['database'] = "cn210627";
$_ENV['user'] = "cn210627";
$_ENV['password'] = "20210627";


// $dbHost="localhost";
// $dbName="xy123456";
// $dbUser="xy123456";
// $dbPassword="**************";


?>